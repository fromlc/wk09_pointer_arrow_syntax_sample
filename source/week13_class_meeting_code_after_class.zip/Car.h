//------------------------------------------------------------------------------
// CS 281-0798, Fall 2021
// Mileage Plan assignment key	   
//------------------------------------------------------------------------------
// Car.h : class declaration file
//------------------------------------------------------------------------------
#pragma once
#ifndef CAR_H
#define CAR_H

#include <string>

#include "Vehicle.h"

class Car : public Vehicle
{
private:
    float mpg;

public:
    Car();
    Car(std::string year, std::string make, std::string model);
    //~Car();

    void setMpg(float mpg);

    float getMpg() const;
};

#endif