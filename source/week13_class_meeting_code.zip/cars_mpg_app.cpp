//------------------------------------------------------------------------------
// CS 281-0798, Fall 2021
// Mileage Plan assignment key	   
//------------------------------------------------------------------------------
// cars_mpg_app.cpp 
//
//	- Uses the Car class
//	= Reads .csv data file
//	- Prompts user for trip length (miles) and gas price (gallon)
//	= Displays trip cost for each car in data set
//------------------------------------------------------------------------------

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

// comment/uncomment next line to toggle verbose debug mode
#define DEBUG

#include "Car.h"
#include "app_utfile.h"
#include "app_utuser.h"

//------------------------------------------------------------------------------
// local function prototypes
//------------------------------------------------------------------------------

void getInput(int& tripMiles, float& gasPrice);
void displayCarData(const Car& car, int tripMiles, float gasPrice);
void displayVData(std::vector<Car>& vCars, int tripMiles, float gasPrice);

// This app does not using namespace std;

//------------------------------------------------------------------------------
// global variables 
//------------------------------------------------------------------------------

// input .csv file
std::string g_fileName = "cars_mpg.csv";

//------------------------------------------------------------------------------
// main() : entry point
//------------------------------------------------------------------------------
int main(int argc, char* argv[])
{
#ifdef DEBUG
	std::cout << "Running app: " << argv[0] << '\n';
#endif
	std::cout << "Trip cost for each car in .csv data file "
		<< g_fileName << '\n';

	// returns valid stream or exits app
	std::ifstream carsFile = openFile(g_fileName);

	if (!carsFile.is_open())
		errorExit(g_fileName, FILE_OPEN_ERROR);

#ifdef DEBUG
	std::cout << "Opened file " << g_fileName << '\n';
#endif

	// avoid vector copy with fill-in function
	std::vector<Car> vCars;
	int lineCount = getFileData(carsFile, vCars);

#ifdef DEBUG
	std::cout << "Read " << lineCount 
		<< " lines of.csv data plus header\n";
#endif

	// done with data file
	carsFile.close();

#ifdef DEBUG
	std::cout << "Closed file " << g_fileName << '\n';
	std::cout << std::endl;
#endif

	// setup fill-in function
	int tripMiles = 0;
	float gasPrice = 0;
	getInput(tripMiles, gasPrice);

	// display results
	displayVData(vCars, tripMiles, gasPrice);

	system("pause");

	return 0;
}

//------------------------------------------------------------------------------
// displayVData()
//------------------------------------------------------------------------------
void displayVData(std::vector<Car>& vCars, int tripMiles, float gasPrice)
{
	for (Car vElement : vCars)
	{
		displayCarData(vElement, tripMiles, gasPrice);
	}
	std::cout << "=======================================\n";
	std::cout << std::endl;
}

//------------------------------------------------------------------------------
// displayCarData()
//------------------------------------------------------------------------------
void displayCarData(const Car& car, int tripMiles, float gasPrice)
{
	std::cout << "=======================================\n";
	std::cout << std::fixed << std::setprecision(2)
		<< car.getYear() << ' '
		<< car.getMake() << ' '
		<< car.getModel() << ' '
		<< std::endl;

	float mpg = car.getMpg();

	std::cout << "MPG: " << mpg << ' '
		<< std::endl;

	std::cout << "Trip cost: $" << tripMiles * gasPrice / mpg
		<< std::endl;
}

