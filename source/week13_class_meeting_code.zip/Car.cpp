//------------------------------------------------------------------------------
// CS 281-0798, Fall 2021
// Mileage Plan assignment key	   
//------------------------------------------------------------------------------
// Car.cpp : class definition file
//------------------------------------------------------------------------------

#include "Car.h"

//------------------------------------------------------------------------------
// constructors
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Car() : default constructor
//------------------------------------------------------------------------------
Car::Car() { this->mpg = 0; }

//------------------------------------------------------------------------------
// Car() : overload constructor
//------------------------------------------------------------------------------
Car::Car(std::string year, std::string make, std::string model)
{ 
    this->year  = year;
    this->make  = make;
    this->model = model;
    this->color = "unpainted";
    this->mpg   = 0;
}

//------------------------------------------------------------------------------
// setter methods
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// setYear() : sets value of member variable year to passed string
//------------------------------------------------------------------------------
void Car::setYear(std::string year)
{
    // the "this pointer" points to this class instance
    this->year = year;
}

//------------------------------------------------------------------------------
// setMake() : copies passed string to member variable maker
//------------------------------------------------------------------------------
void Car::setMake(std::string make)
{
    // the "this pointer" points to this class instance
    this->make = make;
}

//------------------------------------------------------------------------------
// setModel() : copies passed string to member variable model
//------------------------------------------------------------------------------
void Car::setModel(std::string model)
{
    // the "this pointer" points to this class instance
    this->model = model;
}

//------------------------------------------------------------------------------
// setColor() : sets value of member variable color to passed string
//------------------------------------------------------------------------------
void Car::setColor(std::string color)
{
    // the "this pointer" points to this class instance
    this->color = color;
}

//------------------------------------------------------------------------------
// setMpg() : sets value of member variable mpg to passed float
//------------------------------------------------------------------------------
void Car::setMpg(float mpg)
{
    // the "this pointer" points to this class instance
    this->mpg = mpg;
}

//------------------------------------------------------------------------------
// getter methods
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// getYear() : returns a copy of the value of the member variable year
//------------------------------------------------------------------------------
std::string Car::getYear() const
{
    return year;
}

//------------------------------------------------------------------------------
// getMaker() : returns a copy of the value of the member variable maker
//------------------------------------------------------------------------------
std::string Car::getMake() const
{
    return make;
}

//------------------------------------------------------------------------------
// getModel() : returns a copy of the value of the member variable model
//------------------------------------------------------------------------------
std::string Car::getModel() const
{
    return model;
}

//------------------------------------------------------------------------------
// getColor() : returns a copy of the value of the member variable color
//------------------------------------------------------------------------------
std::string Car::getColor() const
{
    return color;
}

//------------------------------------------------------------------------------
// getMpg() : returns the value of member variable mpg
//------------------------------------------------------------------------------
float Car::getMpg() const
{
    // the "this pointer" points to this class instance
    return this->mpg;
}

