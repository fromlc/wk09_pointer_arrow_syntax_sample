//------------------------------------------------------------------------------
// CS 281-0798, Fall 2021
// Mileage Plan assignment key	   
//------------------------------------------------------------------------------
// Car.h : class declaration file
//------------------------------------------------------------------------------
#pragma once
#ifndef CAR_H
#define CAR_H

#include <string>

class Car
{
protected:
    std::string year;
    std::string make;
    std::string model;
    std::string color;

private:
    float mpg;

public:
    Car();
    Car(std::string year, std::string make, std::string model);

    // copy passed strings
    void setYear(
        std::string year);
    void setMake(std::string make);
    void setModel(std::string model);
    void setColor(std::string color);

    void setMpg(float mpg);

    // return a copy of string member data
    std::string getYear() const;
    std::string getMake() const;
    std::string getModel() const;
    std::string getColor() const;

    float getMpg() const;
};

#endif